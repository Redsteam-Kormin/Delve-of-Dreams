A Simple Text-Based Rpg With a Few Features 
-Current Version-
Version 1.0

Features:
-Battle System (On Enemy)
-Equipabbles
-Dev Menu
-Menu Screen
-Stats



Run on Google Colab (or something else.)
